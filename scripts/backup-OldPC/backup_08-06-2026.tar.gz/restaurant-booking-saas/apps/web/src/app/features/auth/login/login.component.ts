import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, signal } from '@angular/core';
import {
    FormControl,
    FormGroup,
    ReactiveFormsModule,
    Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { catchError, finalize, of } from 'rxjs';
import { AuthService } from '../../../core/auth/auth.service';

const LOCALE_KEY = 'locale';
const LOCALE_QUERY_PARAM = 'lang';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, TranslateModule],
  template: `
    <main class="min-h-screen bg-slate-950 text-slate-100 px-4 py-8 sm:px-6 lg:px-8">
      <div class="mx-auto max-w-5xl">
        <section class="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div class="space-y-6 sm:space-y-8">
            <div class="flex flex-col gap-3 rounded-full border border-amber-400/20 bg-amber-400/5 px-4 py-3 text-xs uppercase tracking-[0.24em] text-amber-200 sm:flex-row sm:items-center sm:justify-between">
              <span>{{ 'AUTH.HERO_BADGE' | translate }}</span>
              <div class="inline-flex items-center gap-2 rounded-full bg-slate-950/80 p-1 text-[11px] uppercase tracking-[0.22em] text-slate-200">
                <button
                  type="button"
                  class="rounded-full px-3 py-1 transition hover:bg-slate-900/90 focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  [class.bg-amber-400]="translate.currentLang === 'en'"
                  [class.text-slate-950]="translate.currentLang === 'en'"
                  (click)="setLanguage('en')"
                  [attr.aria-label]="'AUTH.LANGUAGE_EN' | translate"
                >
                  {{ 'AUTH.LANGUAGE_EN' | translate }}
                </button>
                <button
                  type="button"
                  class="rounded-full px-3 py-1 transition hover:bg-slate-900/90 focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  [class.bg-amber-400]="translate.currentLang === 'es'"
                  [class.text-slate-950]="translate.currentLang === 'es'"
                  (click)="setLanguage('es')"
                  [attr.aria-label]="'AUTH.LANGUAGE_ES' | translate"
                >
                  {{ 'AUTH.LANGUAGE_ES' | translate }}
                </button>
              </div>
            </div>
            <div class="space-y-4">
              <p class="text-sm uppercase tracking-[0.3em] text-slate-500">{{ 'AUTH.HERO_SUBHEAD' | translate }}</p>
              <h1 class="text-4xl font-semibold tracking-tight text-slate-50 sm:text-5xl">
                {{ 'AUTH.LOGIN_TITLE' | translate }}
              </h1>
              <p class="max-w-2xl text-slate-400 sm:text-lg">
                {{ 'AUTH.LOGIN_DESCRIPTION' | translate }}
              </p>
            </div>
            <div class="grid gap-4 sm:grid-cols-2">
              <div class="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-5 shadow-[0_18px_45px_-22px_rgba(15,23,42,0.9)]">
                <p class="text-xs uppercase tracking-[0.3em] text-slate-500">{{ 'AUTH.OWNER_ROLE' | translate }}</p>
                <p class="mt-3 text-xl font-semibold text-slate-100">{{ 'AUTH.OWNER_HIGHLIGHT' | translate }}</p>
              </div>
              <div class="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-5 shadow-[0_18px_45px_-22px_rgba(15,23,42,0.9)]">
                <p class="text-xs uppercase tracking-[0.3em] text-slate-500">{{ 'AUTH.MANAGER_ROLE' | translate }}</p>
                <p class="mt-3 text-xl font-semibold text-slate-100">{{ 'AUTH.MANAGER_HIGHLIGHT' | translate }}</p>
              </div>
            </div>
          </div>

          <div class="w-full rounded-[2rem] border border-slate-800/80 bg-slate-900/90 p-6 shadow-[0_40px_120px_-35px_rgba(15,23,42,0.8)] sm:p-8 md:p-10">
            <div class="mb-8">
              <p class="text-sm font-semibold uppercase tracking-[0.32em] text-amber-300/90">{{ 'AUTH.STAFF_LOGIN' | translate }}</p>
              <p class="mt-2 text-slate-400">{{ 'AUTH.STAFF_LOGIN_HELP' | translate }}</p>
            </div>

            <form [formGroup]="form" (ngSubmit)="submit()" class="space-y-6">
              <div class="grid gap-4">
                <label class="block text-sm font-medium text-slate-300">
                  {{ 'AUTH.RESTAURANT_SLUG_LABEL' | translate }}
                  <span class="sr-only">{{ 'AUTH.RESTAURANT_SLUG_HELP' | translate }}</span>
                </label>
                <input
                  formControlName="restaurantSlug"
                  [attr.aria-label]="'AUTH.RESTAURANT_SLUG_LABEL' | translate"
                  placeholder="{{ 'AUTH.RESTAURANT_SLUG_PLACEHOLDER' | translate }}"
                  class="w-full rounded-2xl border border-slate-700 bg-slate-950/70 px-4 py-3 text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400/20"
                />
                <div *ngIf="restaurantSlug.invalid && (restaurantSlug.dirty || restaurantSlug.touched)" class="text-xs text-amber-300">
                  {{ restaurantSlug.hasError('required') ? ('AUTH.RESTAURANT_REQUIRED' | translate) : '' }}
                </div>
              </div>

              <div class="grid gap-5">
                <label class="block text-sm font-medium text-slate-300">{{ 'AUTH.EMAIL_LABEL' | translate }}</label>
                <input
                  formControlName="email"
                  type="email"
                  [attr.aria-label]="'AUTH.EMAIL_LABEL' | translate"
                  placeholder="{{ 'AUTH.EMAIL_PLACEHOLDER' | translate }}"
                  class="w-full rounded-2xl border border-slate-700 bg-slate-950/70 px-4 py-3 text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400/20"
                />
                <div *ngIf="email.invalid && (email.dirty || email.touched)" class="text-xs text-amber-300">
                  <span *ngIf="email.hasError('required')">{{ 'AUTH.EMAIL_REQUIRED' | translate }}</span>
                  <span *ngIf="email.hasError('email')">{{ 'AUTH.EMAIL_INVALID' | translate }}</span>
                </div>
              </div>

              <div class="grid gap-5">
                <label class="block text-sm font-medium text-slate-300">{{ 'AUTH.PASSWORD_LABEL' | translate }}</label>
                <input
                  formControlName="password"
                  type="password"
                  [attr.aria-label]="'AUTH.PASSWORD_LABEL' | translate"
                  placeholder="{{ 'AUTH.PASSWORD_PLACEHOLDER' | translate }}"
                  class="w-full rounded-2xl border border-slate-700 bg-slate-950/70 px-4 py-3 text-slate-100 placeholder:text-slate-500 focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400/20"
                />
                <div *ngIf="password.invalid && (password.dirty || password.touched)" class="text-xs text-amber-300">
                  <span *ngIf="password.hasError('required')">{{ 'AUTH.PASSWORD_REQUIRED' | translate }}</span>
                  <span *ngIf="password.hasError('minlength')">{{ 'AUTH.PASSWORD_MINLENGTH' | translate }}</span>
                </div>
              </div>

              <div *ngIf="serverErrorValue" class="rounded-2xl bg-amber-500/10 border border-amber-400/30 px-4 py-3 text-sm text-amber-200">
                <ng-container *ngIf="serverErrorArray; else singleError">
                  <ul class="list-disc pl-4">
                    <li *ngFor="let err of serverErrorArray">{{ err }}</li>
                  </ul>
                </ng-container>
                <ng-template #singleError>{{ serverErrorValue }}</ng-template>
              </div>

              <button
                type="submit"
                [disabled]="isSubmitting() || form.invalid"
                class="inline-flex w-full justify-center rounded-2xl bg-amber-400 px-5 py-3 text-sm font-semibold text-slate-950 shadow-sm transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <span *ngIf="!isSubmitting()">{{ 'AUTH.LOGIN_SUBMIT' | translate }}</span>
                <span *ngIf="isSubmitting()">{{ 'AUTH.SIGNING_IN' | translate }}</span>
              </button>
            </form>

            <p class="mt-6 text-center text-xs uppercase tracking-[0.28em] text-slate-600">
              {{ 'AUTH.LOGIN_TAGLINE' | translate }}
            </p>
          </div>
        </section>
      </div>
    </main>
  `,
})
export class LoginComponent {
  readonly form = new FormGroup({
    restaurantSlug: new FormControl('', {
      nonNullable: true,
      validators: Validators.required,
    }),
    email: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    password: new FormControl('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(8)],
    }),
  });

  readonly isSubmitting = signal(false);
  readonly serverError = signal<string | string[] | null>(null);

  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    public readonly translate: TranslateService,
  ) {}

  isServerErrorArray(): boolean {
    const v = this.serverError();
    return Array.isArray(v);
  }

  get serverErrorValue(): string | string[] | null {
    return this.serverError();
  }

  get serverErrorArray(): string[] | null {
    const v = this.serverError();
    return Array.isArray(v) ? (v as string[]) : null;
  }

  setLanguage(language: 'en' | 'es'): void {
    // persist the selection locally and in the current URL for shareable state
    localStorage.setItem(LOCALE_KEY, language);
    this.translate.use(language);
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { [LOCALE_QUERY_PARAM]: language },
      queryParamsHandling: 'merge',
      replaceUrl: true,
    });
  }

  get restaurantSlug() {
    return this.form.get('restaurantSlug')!;
  }

  get email() {
    return this.form.get('email')!;
  }

  get password() {
    return this.form.get('password')!;
  }

  submit(): void {
    if (this.form.invalid || this.isSubmitting()) {
      this.form.markAllAsTouched();
      return;
    }

    this.serverError.set(null);
    this.isSubmitting.set(true);

    this.authService
      .login(this.form.getRawValue())
      .pipe(
        finalize(() => this.isSubmitting.set(false)),
        catchError((error: HttpErrorResponse) => {
          if (error?.status === 400) {
            const message = error.error?.message;
            if (Array.isArray(message)) {
              this.serverError.set(message as string[]);
            } else if (typeof message === 'string') {
              this.serverError.set(message);
            } else {
              this.serverError.set(this.translate.instant('AUTH.VALIDATION_ERROR'));
            }
          } else if (error?.status === 401) {
            const message = error.error?.message;
            this.serverError.set(
              typeof message === 'string' && message !== 'Invalid credentials'
                ? message
                : this.translate.instant('AUTH.INVALID_CREDENTIALS'),
            );
          } else {
            const message = error.error?.message;
            this.serverError.set(
              typeof message === 'string'
                ? message
                : this.translate.instant('AUTH.LOGIN_GENERIC_ERROR'),
            );
          }
          return of(null);
        }),
      )
      .subscribe((result) => {
        if (result?.accessToken) {
          this.router.navigate(['/dashboard']);
        }
      });
  }
}
